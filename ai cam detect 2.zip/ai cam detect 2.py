import cv2
import time
import numpy as np
from ultralytics import YOLO

# -----------------------------
# Load model
# -----------------------------
model = YOLO("yolov8n.pt")

# -----------------------------
# Webcam
# -----------------------------
cap = cv2.VideoCapture(0)

# -----------------------------
# Tracking memory
# -----------------------------
person_times = {}

# Loitering threshold (seconds)
LOITER_TIME = 15

# Queue zone
QUEUE_X1 = 100
QUEUE_Y1 = 100
QUEUE_X2 = 500
QUEUE_Y2 = 400

print("AI Surveillance Started")

while True:

    ret, frame = cap.read()

    if not ret:
        break

    current_time = time.time()

    # -----------------------------
    # Track people
    # -----------------------------
    results = model.track(
        frame,
        persist=True
    )

    queue_count = 0

    for r in results:

        boxes = r.boxes

        for box in boxes:

            cls_id = int(box.cls[0])
            class_name = model.names[cls_id]

            if class_name != "person":
                continue

            x1, y1, x2, y2 = map(
                int,
                box.xyxy[0]
            )

            # Tracking ID
            if box.id is None:
                continue

            track_id = int(box.id[0])

            # Center point
            cx = int((x1 + x2) / 2)
            cy = int((y1 + y2) / 2)

            # -----------------------------
            # Loitering detection
            # -----------------------------
            if track_id not in person_times:
                person_times[track_id] = current_time

            duration = current_time - person_times[track_id]

            color = (0,255,0)

            if duration > LOITER_TIME:
                color = (0,0,255)

                cv2.putText(
                    frame,
                    f'LOITERING ID:{track_id}',
                    (x1, y1 - 40),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.7,
                    (0,0,255),
                    2
                )

            # -----------------------------
            # Queue Analysis
            # -----------------------------
            in_queue_zone = (
                QUEUE_X1 < cx < QUEUE_X2 and
                QUEUE_Y1 < cy < QUEUE_Y2
            )

            if in_queue_zone:
                queue_count += 1

            # Draw person box
            cv2.rectangle(
                frame,
                (x1,y1),
                (x2,y2),
                color,
                2
            )

            cv2.putText(
                frame,
                f'ID:{track_id}',
                (x1, y1 - 10),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                color,
                2
            )

    # -----------------------------
    # Draw Queue Zone
    # -----------------------------
    cv2.rectangle(
        frame,
        (QUEUE_X1, QUEUE_Y1),
        (QUEUE_X2, QUEUE_Y2),
        (255,0,0),
        2
    )

    cv2.putText(
        frame,
        f'Queue Count: {queue_count}',
        (20,40),
        cv2.FONT_HERSHEY_SIMPLEX,
        1,
        (255,0,0),
        2
    )

    # Queue warning
    if queue_count > 5:
        cv2.putText(
            frame,
            "⚠ LONG QUEUE DETECTED",
            (20,80),
            cv2.FONT_HERSHEY_SIMPLEX,
            1,
            (0,0,255),
            3
        )

    cv2.imshow(
        "Loitering + Queue Analysis",
        frame
    )

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
