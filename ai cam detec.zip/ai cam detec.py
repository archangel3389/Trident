import cv2
import easyocr
from ultralytics import YOLO

# -----------------------------
# Models
# -----------------------------
person_model = YOLO("yolov8n.pt")

# Use custom plate detector for best results
plate_model = YOLO("license_plate_detector.pt")

ocr_reader = easyocr.Reader(['en'])

cap = cv2.VideoCapture(0)

while True:

    ret, frame = cap.read()

    if not ret:
        break

    # -----------------------------
    # PERSON / CROWD ANALYSIS
    # -----------------------------
    person_results = person_model.track(
        frame,
        persist=True
    )

    person_count = 0

    for r in person_results:

        for box in r.boxes:

            cls_id = int(box.cls[0])
            class_name = person_model.names[cls_id]

            if class_name == "person":

                person_count += 1

                x1, y1, x2, y2 = map(
                    int,
                    box.xyxy[0]
                )

                cv2.rectangle(
                    frame,
                    (x1,y1),
                    (x2,y2),
                    (0,255,0),
                    2
                )

    # Crowd level estimation
    crowd_status = "LOW"

    if person_count > 5:
        crowd_status = "MEDIUM"

    if person_count > 15:
        crowd_status = "HIGH"

    cv2.putText(
        frame,
        f'People: {person_count} Crowd: {crowd_status}',
        (20,40),
        cv2.FONT_HERSHEY_SIMPLEX,
        1,
        (0,255,255),
        2
    )

    # -----------------------------
    # LICENSE PLATE DETECTION
    # -----------------------------
    plate_results = plate_model(frame)

    for r in plate_results:

        for box in r.boxes:

            x1, y1, x2, y2 = map(
                int,
                box.xyxy[0]
            )

            plate_crop = frame[y1:y2, x1:x2]

            # OCR
            text_results = ocr_reader.readtext(
                plate_crop
            )

            plate_text = "UNKNOWN"

            if len(text_results) > 0:
                plate_text = text_results[0][-2]

            cv2.rectangle(
                frame,
                (x1,y1),
                (x2,y2),
                (255,0,0),
                2
            )

            cv2.putText(
                frame,
                plate_text,
                (x1, y1 - 10),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.9,
                (255,0,0),
                2
            )

    cv2.imshow("Advanced AI Security System", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
